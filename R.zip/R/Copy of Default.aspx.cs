﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;

public partial class _Default : System.Web.UI.Page
{
    RijndaelManaged myRijndael;
    string original="";
    string ByteToString(byte[] encrypted)
    {
        string s = "";
        foreach (byte b in encrypted)
        {
            Console.Write(Convert.ToChar(b));
            s += Convert.ToChar(b);
        }
        return s;
    }

    byte[] StringToByte(string s)
    {
        byte[] bytes= new byte[s.Length];
        int i = 0;
        foreach (char c in s)
        {
            Console.Write(Convert.ToByte(c));
            bytes[i++] += Convert.ToByte(c);
        }
        return bytes;
    }
    string ByteToChars(byte[] encrypted)
    {
        string s = "";
        foreach (byte b in encrypted)
        {
            Console.Write(Convert.ToChar(b));
            s +=", "+ Convert.ToChar(b);
        }
        return s;
    }

    static byte[] EncryptStringToBytes(string plainText, byte[] Key, byte[] IV)
        {
            byte[] encrypted;
            // Create an RijndaelManaged object
            // with the specified key and IV.
            using (RijndaelManaged rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;

                // Create an encryptor to perform the stream transform.
                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV), CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {

                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();

                    }
                }
            }

            // Return the encrypted bytes from the memory stream.
            return encrypted;
        }



    //------------------------------------------------------------------
    protected void Page_Load(object sender, EventArgs e)
    {
               try
            {

                original = "";

                // Create a new instance of the RijndaelManaged
                // class. This generates a new key and initialization
                // vector (IV).
                using ( myRijndael = new RijndaelManaged())
                {
                   
                    myRijndael.Key = StringToByte(TextBox1.Text); //key;
                    myRijndael.IV = StringToByte(TextBox2.Text);//iv;
                    // Encrypt the string to an array of bytes.
                    byte[] encrypted = EncryptStringToBytes(original, myRijndael.Key, myRijndael.IV);

                    // Decrypt the bytes to a string.
                    string roundtrip = DecryptStringFromBytes(encrypted, myRijndael.Key, myRijndael.IV);

                    //Display the original data and the decrypted data.
                    Result.Text ="Original: "+original;
                    Result.Text +="<br>Round Trip:" + roundtrip ;
                    string s="";

                    s=ByteToString(encrypted);
                    /*foreach (byte b in encrypted)
                    {
                        Console.Write(Convert.ToChar(b));
                        s += Convert.ToChar(b);
                    }*/

                    byte[] Encrypted= new byte[s.Length];

                    int i=0;

                    foreach (char c in s)
                    {
                        Encrypted[i++]=Convert.ToByte(c);
                    }

                    roundtrip = DecryptStringFromBytes(Encrypted, myRijndael.Key, myRijndael.IV);


                    Result.Text += "<br>encrypted text:";
                    //Result.Text+=encrypted+"<br>";
                    Result.Text+=s;

                    Result.Text+="<br>Round Trip-2: "+roundtrip;
                    Result.Text += "<br><br>";
                    
                }
            }
            catch (Exception ex)
            {      
              ERROR.Text=ex.Message;
            }
        } //Page_Load



static string DecryptStringFromBytes(byte[] cipherText, byte[] Key, byte[] IV)
        {


            // Declare the string used to hold
            // the decrypted text.
            string plaintext = null;

            // Create an RijndaelManaged object
            // with the specified key and IV.
            using (RijndaelManaged rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;

                // Create a decryptor to perform the stream transform.
                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }

            return plaintext;
        }
protected void Button1_Click(object sender, EventArgs e)
{
    myRijndael.Key = StringToByte(TextBox1.Text); //key;
    myRijndael.IV = StringToByte(TextBox2.Text);//iv;
    byte[] encrypted = EncryptStringToBytes(original, myRijndael.Key, myRijndael.IV);

    // Decrypt the bytes to a string.
    string roundtrip = DecryptStringFromBytes(encrypted, myRijndael.Key, myRijndael.IV);

    //Display the original data and the decrypted data.
    Result.Text = "Original: " + original;
    Result.Text += "<br>Round Trip:" + roundtrip;
    string s = "";

    s = ByteToString(encrypted);
    ERROR.Text = s+"<br>"+roundtrip;
}
protected void Button2_Click(object sender, EventArgs e)
{
    byte[] key = { 0x04, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
    byte[] iv = { 0x04, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
    //Label1.Text = "key=" + ByteToString(key) + "  " + ByteToChars(key);
    TextBox1.Text = ByteToString(key);
    //Label2.Text = "iv=" + ByteToString(iv);
    TextBox2.Text = ByteToString(iv);
 
}
protected void Button3_Click(object sender, EventArgs e)
{

}

protected void btn_IMG_GenerateKey_Click(object sender, ImageClickEventArgs e)
{
    byte[] key = { 0x04, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
    byte[] iv = { 0x04, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16 };
    //Label1.Text = "key=" + ByteToString(key) + "  " + ByteToChars(key);
    tbxKey.Text = ByteToString(key);
    //Label2.Text = "iv=" + ByteToString(iv);
    tbxIv.Text = ByteToString(iv);
}
protected void btnIMG_Encrypt_Click(object sender, ImageClickEventArgs e)
{
    if (tbxKey.Text.Length == 0)
    {
        lblERROR.Text = "Generate key ↑";
        return;
    }
    if (tbxKey.Text.Length == 0)
    {
        lblERROR.Text = "Generate key ↑";
        return;
    }
    myRijndael.Key = StringToByte(tbxKey.Text);
    myRijndael.IV = StringToByte(tbxIv.Text);//iv;
    original = txtText_to_Encrypt.Text;
    byte[] encrypted = EncryptStringToBytes(original, myRijndael.Key, myRijndael.IV);
    txtChiperText.Text = ByteToString(encrypted);
}
protected void btnIMG_Decrypt_Click(object sender, ImageClickEventArgs e)
{
    if (tbxKey.Text.Length == 0)
    {
        lblERROR.Text = "Generate key ↑";
        return;
    }
    if (tbxKey.Text.Length == 0)
    {
        lblERROR.Text = "Generate key ↑";
        return;
    }
    myRijndael.Key = StringToByte(tbxKey.Text);
    myRijndael.IV = StringToByte(tbxIv.Text);//iv;
    byte[] encrypted = StringToByte(txtChiperText.Text);
    // Decrypt the bytes to a string.
    string roundtrip = DecryptStringFromBytes(encrypted, myRijndael.Key, myRijndael.IV);
    txtDecpyptedText.Text = roundtrip;
  }
}


