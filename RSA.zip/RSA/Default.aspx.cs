﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;


public partial class RSA_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void cmbGO_Click(object sender, EventArgs e)
    {
        DateTime dt1 = DateTime.Now;
        DateTime dt2;

        var key = int.Parse(tbxKey.Text);
        var rsa = new RSACryptoServiceProvider(key);
        //получить private key
        var privateKey = rsa.ExportParameters(true);
        //получить public key ...
        var publicKey = rsa.ExportParameters(false);

        var str = tbxTextInitial.Text;
        var rsa_enc = new RSACryptoServiceProvider(key);
        rsa_enc.ImportParameters(publicKey);
        var bytesStr = System.Text.Encoding.Unicode.GetBytes(str);
        //собственно шифрование
        var bytesCypherStr = rsa_enc.Encrypt(bytesStr, false);
        //преобразование зашифрованного массива байт в строку
        string cypherText = Convert.ToBase64String(bytesCypherStr);
        tbxEncrypted.Text = cypherText;


        //РАСШИРОВКА
        //преобразуем строку в массив байт
        bytesCypherStr =
                     Convert.FromBase64String(cypherText);
        //загружаем наш private key
        var rsa_dec = new RSACryptoServiceProvider();
        rsa_dec.ImportParameters(privateKey);
        //собственно расшифровка
        bytesStr = rsa_dec.Decrypt(bytesCypherStr, false);
        //Преобразование массива данных в строку
        string decipherText = System.Text.Encoding.Unicode.GetString(bytesStr);
        tbxDecrypted.Text=decipherText;
        dt2 = DateTime.Now;
        Label3.Text = dt1.Hour + ":" + dt1.Minute + ":" + dt1.Second + ":<u>" + dt1.Millisecond+"</u>";
        Label2.Text = dt2.Hour + ":" + dt2.Minute + ":" + dt2.Second + ":<u>" + dt2.Millisecond + "</u><b> - </b>";
        TimeSpan ts = dt2.Subtract(dt1);
        Label1.Text = "<u>"+Math.Truncate(float.Parse(ts.TotalMilliseconds.ToString())) + "</u> ms. <b> = </b>";

    }
}