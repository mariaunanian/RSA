﻿
Partial Class Protected_Default
    Inherits System.Web.UI.Page

End Class
